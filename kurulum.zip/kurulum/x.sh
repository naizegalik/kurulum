#!/bin/bash

sudo apt install -y libsodium-dev libgmp3-dev cmake g++ git

git clone https://github.com/madMAx43v3r/chia-plotter.git 

cd chia-plotter

git submodule update --init

./make_devel.sh

cd build
mkdir /root/temp
mkdir /root/plt
chmod +x /root/temp
chmod +x /root/plt


./chia_plot -n -1 -r 16 -u 256 -t /root/temp/ -2 /root/temp/ -d /root/plt/ -c xch1m34zpgre2cz406neagtfjxgt6q4sffu37e9txctn2gx3ex0dw66qxzn5lz -f 8d32e1645c12df89131e03484569ff5287e09ed5a39ff5df7fb1c671eb730ae4aef20155d7babb4fd86f1eb5b8719487

