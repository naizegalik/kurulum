#!/bin/bash
echo "Basladi"
while [ true ]
do
  for file in *
  do
    if [[ $file == *.plot ]]; then
      index="$((1 + $RANDOM % 700))"
      counter="$((1 + $RANDOM % 488))"
      acc="$index.json"
      rclone move $file drive$counter: --user-agent="ISV|rclone.org|rclone/v1.61.0-beta.6610.beea4d511" --buffer-size=32M --drive-chunk-size=16M --drive-upload-cutoff=1000T --drive-pacer-min-sleep=700ms --checksum --check-first --drive-acknowledge-abuse --copy-links --drive-stop-on-upload-limit --no-traverse --tpslimit-burst=0 --retries=3 --low-level-retries=10 --checkers=14 --tpslimit=1 --transfers=7 --fast-list --drive-service-account-file /root/.config/rclone/accounts/"$acc" -P
      sleep 5
    fi
  done
  sleep 5
done
